﻿namespace Nuevoproyect.Pages;
using Nuevoproyect.Data.Services;
using Nuevoproyect.Data.Respons;
using Nuevoproyect.Data.Modelos;
using Nuevoproyect.Data.Request;


public class AuthService
    {
    private readonly IRegistroservices registroservices;

    public AuthService(IRegistroservices registroservices)
    {
        this.registroservices = registroservices;
    }

    public async Task<Result<LoginResponse>> Login(string email, string password)
    {
        // Verificar las credenciales del usuario llamando a GetUserByEmailAndPassword()
        var result = await registroservices.GetUserByEmailAndPassword(email, password);

        if (result.succcess && result.Data != null)
        {
            // Las credenciales son válidas, el usuario ha sido encontrado en la base de datos
            // Realiza las acciones necesarias, como establecer la sesión del usuario, generar tokens, etc.

            // Por ejemplo, puedes devolver un objeto de respuesta con el usuario y un mensaje de éxito
            var loginResponse = new LoginResponse
            {
                Usuario = result.Mensaje,
                Mensaje = "Login exitoso"
            };

            return new Result<LoginResponse>
            {
                Mensaje = loginResponse.Mensaje,
                succcess = true,
                Data = loginResponse
            };
        }
        else
        {
            // Las credenciales son inválidas, el usuario no ha sido encontrado en la base de datos
            // Puedes devolver un mensaje de error apropiado
            return new Result<LoginResponse>
            {
                Mensaje = "Credenciales inválidas",
                succcess = false,
                Data = null
            };
        }
    }


}

