﻿using System.ComponentModel.DataAnnotations;

namespace Nuevoproyect.Data.Request
{
    public class Registrorequest
    {
       
            
            public int Id { get; set; }
            public string Correo { get; set; } = null!;
            public string Clave { get; set; } = null!;
            public string Confirmarclave { get; set; } = null!;
            public string Nombre { get; set; } = null!;
            public string Apellido { get; set; } = null!;
        
    }
}
