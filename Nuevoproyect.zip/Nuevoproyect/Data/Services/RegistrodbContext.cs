﻿namespace Nuevoproyect.Data.Services
{
    public class RegistrodbContext
    {
    }
}