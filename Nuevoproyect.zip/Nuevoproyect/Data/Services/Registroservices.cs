﻿using Microsoft.EntityFrameworkCore;
using Nuevoproyect.Data.Context;
using Nuevoproyect.Data.Modelos;
using Nuevoproyect.Data.Request;
using Nuevoproyect.Data.Respons;
using Nuevoproyect.Data.Services;

namespace Nuevoproyect.Data.Services
{
    public class Result
    {
        public bool succcess { get; set; }
        public string? Mensaje { get; set; }


    }
    public class Result<T>
    {
        public bool succcess { get; set; }
        public string? Mensaje { get; set; }
        public T? Data { get; set; }

    }
    public class Registroservices : IRegistroservices
    {

        private readonly IRegistrodbcontext dbcontext;

        public Registroservices(IRegistrodbcontext dbcontext)
        {
            this.dbcontext = dbcontext;
        }

        public async Task<Result> Crear(Registrorequest request)
        {
            try
            {
                var registro = Registro.Crear(request);
                dbcontext.Registros.Add(registro);
                await dbcontext.SaveChangesAsync();
                return new Result() { Mensaje = "Ok", succcess = true };
            }
            catch (Exception E)
            {
                return new Result() { Mensaje = E.Message, succcess = false };


            }
        }
        public async Task<Result> Modicicar(Registrorequest request)
        {
            try
            {

                var registro = await dbcontext.Registros.FirstOrDefaultAsync(c => c.Id == request.Id);
                if (registro == null)
                    return new Result() { Mensaje = "No se encontro  el usuario", succcess = false };

                if (registro.Modificar(request))
                    await dbcontext.SaveChangesAsync();

                return new Result() { Mensaje = "Ok", succcess = true };
            }
            catch (Exception E)
            {
                return new Result() { Mensaje = E.Message, succcess = false };


            }
        }
        public async Task<Result> Eliminar(Registrorequest request)
        {
            try
            {

                var registro = await dbcontext.Registros.FirstOrDefaultAsync(c => c.Id == request.Id);
                if (registro == null)
                    return new Result() { Mensaje = "No se encontro  el usuario", succcess = false };
                dbcontext.Registros.Remove(registro);
                await dbcontext.SaveChangesAsync();




                return new Result() { Mensaje = "Ok", succcess = true };
            }
            catch (Exception E)
            {
                return new Result() { Mensaje = E.Message, succcess = false };


            }
        }
        public async Task<Result<List<Registrorespons>>> Consultar(string filtro)
        {
            try
            {
                var registro = await dbcontext.Registros.Where(c => (c.Nombre + "" + c.Apellido + "" + c.Correo + "" + c.Clave + "" + c.Confirmarclave).ToLower().Contains(filtro.ToLower())).Select(c => c.Toresponse()).ToListAsync();
                return new Result<List<Registrorespons>> { Mensaje = "ok", succcess = true, Data = registro };

            }
            catch (Exception E)
            {
                return new Result<List<Registrorespons>> { Mensaje = E.Message, succcess = false };


            }
        }

        public Task<Result> Modificar(Registrorequest request)
        {
            throw new NotImplementedException();
        }
        public async Task<Result<Registrorespons>> GetUserByEmailAndPassword(string email, string password)
        {
            try
            {
                // Consulta la base de datos para encontrar el usuario por correo electrónico y contraseña
                var user = await dbcontext.Registros
                    .FirstOrDefaultAsync(r => r.Correo == email && r.Clave == password);

                // Devuelve el resultado con el usuario encontrado o nulo si no se encontró ninguno
                return new Result<Registrorespons>
                {
                    Mensaje = "Ok",
                    succcess = true,
                    Data = user != null ? user.Toresponse() : null
                };
            }
            catch (Exception E)
            {
                // Manejo de errores si ocurre alguna excepción
                return new Result<Registrorespons>
                {
                    Mensaje = E.Message,
                    succcess = false,
                    Data = null
                };
            }
        }


    }
}

