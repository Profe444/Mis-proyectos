﻿using Microsoft.EntityFrameworkCore;
using Nuevoproyect.Data.Context;
using Nuevoproyect.Data.Request;
using Nuevoproyect.Data.Respons;

namespace Nuevoproyect.Data.Services
{
    public interface IRegistroservices
    {

       

        Task<Result<List<Registrorespons>>> Consultar(string filtro);
        Task<Result> Crear(Registrorequest request);
        Task<Result> Eliminar(Registrorequest request);
        Task<Result> Modificar(Registrorequest request);
        Task<Result<Registrorespons>> GetUserByEmailAndPassword(string email,
                                                                string password);

    }
}