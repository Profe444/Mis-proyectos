﻿using Nuevoproyect.Data.Request;
using Nuevoproyect.Data.Respons;
using System.ComponentModel.DataAnnotations;

namespace Nuevoproyect.Data.Modelos
{
    public class Registro
    {
        [Key]
        public int Id { get; set; }
        public string Correo { get; set; } = null!;
        public string Clave { get; set; } = null!;
        public string Confirmarclave { get; set; } = null!;
        public string Nombre { get; set; } = null!;
        public string Apellido { get; set; } = null!;
        public static Registro Crear(Registrorequest registro)
        => new()
        {
            Nombre = registro.Nombre,
            Apellido=  registro.Apellido,
            Correo =  registro.Correo,
            Clave= registro.Clave,
            Confirmarclave=  registro.Confirmarclave,

        };
        public bool Modificar(Registrorequest registro)
        {
            var cambio = false;
            if(Nombre!= registro.Nombre)
            {
                Nombre = registro.Nombre;
                cambio = true;
            }
            return cambio;
            if (Apellido != registro.Apellido)
            {
                Apellido = registro.Apellido;
                cambio = true;
            }
            return cambio;
            if (Correo != registro.Correo)
            {
                Correo = registro.Correo;
                cambio = true;
            }
            return cambio;
            if (Clave != registro.Clave)
            {
                Clave = registro.Clave;
                cambio = true;
            }
            return cambio;

            if (Confirmarclave != registro.Confirmarclave)
            {
                Confirmarclave = registro.Confirmarclave;
                cambio = true;
            }
            return cambio;
        }
        public Registrorespons Toresponse()
        => new Registrorespons()
        {
            Nombre = Nombre,
            Clave = Clave,
            Confirmarclave = Confirmarclave,
            Apellido=Apellido,
            Correo=Correo, 
            
        };
        
        
        
        
    }
}
