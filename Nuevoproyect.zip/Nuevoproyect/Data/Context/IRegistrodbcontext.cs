﻿using Microsoft.EntityFrameworkCore;
using Nuevoproyect.Data.Modelos;

namespace Nuevoproyect.Data.Context
{
    public interface IRegistrodbcontext
    {
         public DbSet<Registro> Registros { get; set; }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    }
}