﻿using Microsoft.EntityFrameworkCore;
using Nuevoproyect.Data.Modelos;
using System.Diagnostics.Contracts;

namespace Nuevoproyect.Data.Context
{
    public class Registrodbcontext : DbContext, IRegistrodbcontext
    {
        private readonly IConfiguration config;

        public Registrodbcontext(IConfiguration config)
        {
            this.config = config;
        }
        public DbSet<Registro> Registros { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(config.GetConnectionString("MSSQL"));
        }
        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            return base.SaveChangesAsync(cancellationToken);
        }
    }
}
