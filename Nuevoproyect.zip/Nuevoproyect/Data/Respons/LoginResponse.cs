﻿namespace Nuevoproyect.Data.Respons
{
    public class LoginResponse
    {
        
            // Propiedades de la clase LoginResponse
            public string Usuario { get; set; }
            public string Mensaje { get; set; }
        
    }
}
