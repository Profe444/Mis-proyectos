﻿using Nuevoproyect.Data.Request;

namespace Nuevoproyect.Data.Respons
{
    public class Registrorespons
    {
        public int Id { get; set; }
        public string Correo { get; set; } = null!;
        public string Clave { get; set; } = null!;
        public string Confirmarclave { get; set; } = null!;
        public string Nombre { get; set; } = null!;
        public string Apellido { get; set; } = null!;

        public Registrorequest Torequest()
        {
            return new Registrorequest { Id = Id, Nombre = Nombre, Apellido = Apellido, Correo=Correo, Clave=Clave, Confirmarclave=Confirmarclave };
        }
    }
}
